﻿// File Prologue
// Name: Montana Newman     
// CS 1400 Section 004
// Project: CS1400_Lab_01
// Date: 8/26/2014 2:35:44 PM
// 
// I declare that the following code was written by me or provided 
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
// ---------------------------------------------------------------------------

using System;

static class Program
{
    static void Main()
    {
        // This program display my student information
        string name = "Montana Newman";
        string course = "CNS 1400";
        string section = "004";
        string project = "Lab One";


        // This code displays the string on the console
        Console.WriteLine("Name: {0}", name);
        Console.WriteLine("Course: {0}", course);
        Console.WriteLine("Section: {0}", section);
        Console.WriteLine("Project: {0}", project);

        Console.ReadLine();
    }//End Main()
}//End class Program
